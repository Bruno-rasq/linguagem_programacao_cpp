#pragma once

class Coordenada {

    private:
        int x, y;

    public:
        void setCoordenadas(int x, int y);
        int getCoordenadaX();
        int getCoordenadaY();
};